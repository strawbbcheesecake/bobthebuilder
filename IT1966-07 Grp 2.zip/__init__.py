from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from Forms import CreateUserForm
from Form2 import CreatePaymentForm
from Form3 import CreateQuiz
from Form4 import CreateFeedback
import shelve, User, Payment, Feedback
import Question
app = Flask(__name__)
app.secret_key = "any_random_string"


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    create_user_form = CreateUserForm(request.form)
    if request.method == 'POST':
        users_dict = {}
        db = shelve.open('user.db', 'c')
        try:
            users_dict = db['Users']
        except:
            print("Error in retrieving Users from user.db.")

        if create_user_form.user_name.data in users_dict:
            errormessage = "Username in used."
            return render_template('signup.html', form=create_user_form, errormessage=errormessage)

        # chweck if username is in shelve if else
        user = User.User(create_user_form.first_name.data,  create_user_form.last_name.data,
                         create_user_form.email.data, create_user_form.gender.data,
                         create_user_form.user_name.data, create_user_form.password.data)
        users_dict[user.get_user_name()] = user
        db['Users'] = users_dict

        db.close()

        return render_template('home.html')
    return render_template('signup.html', form=create_user_form)

@app.route('/createPayment', methods=['GET', 'POST'])
def create_payment():
    create_payment_form = CreatePaymentForm(request.form)
    if request.method == 'POST':
        payments_dict = {}
        db = shelve.open('payment.db', 'c')
        try:
            payments_dict = db['Payments']
        except:
            print("Error in retrieving Payment from payments.db.")
        payment = Payment.Payment(create_payment_form.full_name.data, create_payment_form.email.data,
                         create_payment_form.address.data, create_payment_form.postal_code.data, create_payment_form.name_on_card.data,
                         create_payment_form.card_number.data, create_payment_form.exp_month.data, create_payment_form.exp_year.data,
                         create_payment_form.cvc.data)
        payments_dict[payment.get_payment_id()] = payment
        db['Payments'] = payments_dict

        db.close()

        return render_template('paymentConfirm.html')
    return render_template('createPayment.html', form=create_payment_form)

@app.route('/retrievePayments')
def retrieve_payments():
    payments_dict = {}
    db = shelve.open('payment.db', 'r')
    payments_dict = db['Payments']
    db.close()

    payments_list = []
    for key in payments_dict:
        payment = payments_dict.get(key)
        payments_list.append(payment)
    return render_template('retrievePayments.html', count=len(payments_list), payments_list=payments_list)
@app.route('/updatePayment/<int:id>/', methods=['GET', 'POST'])
def update_payment(id):
    update_payment_form = CreatePaymentForm(request.form)
    if request.method == 'POST' and update_payment_form.validate():
        payments_dict ={}
        db = shelve.open('payment.db', 'w')
        payments_dict = db['Payments']
        payment = payments_dict.get(id)
        payment.set_full_name(update_payment_form.full_name.data)
        payment.set_email(update_payment_form.email.data)
        payment.set_address(update_payment_form.address.data)
        payment.set_postal_code(update_payment_form.postal_code.data)
        payment.set_name_on_card(update_payment_form.name_on_card.data)
        payment.set_card_number(update_payment_form.card_number.data)
        payment.set_exp_month(update_payment_form.exp_month.data)
        payment.set_exp_year(update_payment_form.exp_year.data)
        payment.set_cvc(update_payment_form.cvc.data)

        db['Payments'] = payments_dict
        db.close()
        return redirect(url_for('retrieve_payments'))
    else:
        payments_dict = {}
        db = shelve.open('payment.db', 'r')
        payments_dict = db['Payments']
        db.close()
        payment = payments_dict.get(id)
        update_payment_form.full_name.data = payment.get_full_name()
        update_payment_form.email.data = payment.get_email()
        update_payment_form.address.data = payment.get_address()
        update_payment_form.postal_code.data = payment.get_postal_code()
        update_payment_form.name_on_card.data = payment.get_name_on_card()
        update_payment_form.card_number.data = payment.get_card_number()
        update_payment_form.exp_month.data = payment.get_exp_month()
        update_payment_form.exp_year.data = payment.get_exp_year()
        update_payment_form.cvc.data = payment.get_cvc()
        return render_template('updatePayment.html', form=update_payment_form)

@app.route('/deletePayment/<int:id>', methods=['POST'])
def delete_payment(id):
    payments_dict = {}
    db = shelve.open('payment.db', 'w')
    payments_dict = db['Payments']

    payments_dict.pop(id)

    db['Payments'] = payments_dict
    db.close()

    return redirect(url_for('retrieve_payments'))

products = [
    {"id": 1, "name": "Metal Straws Set", "desc": "4 Metal Straws + 1 Floss", "price": 4.50, "image": "metalsta.png"},
    {"id": 2, "name": "Bamboo Straws Set", "desc": "6 Bamboo straws + 1 Floss", "price": 7.50, "image": "bamboos.png"},
    {"id": 3, "name": "Glass Straws Set", "desc": "2 straight, 2 Curved straws + 1 Floss", "price": 5.50,
     "image": "glasss.png"},
    {"id": 4, "name": "Cutlery set:", "desc": "Spoon,fork,chopstick", "price": 5.50, "image": "cutlery.png"},
    {"id": 5, "name": "Cutlery set 2:", "desc": "Spoon,fork,chopstick, straw, floss", "price": 6.00,
     "image": "cutlery2.jpg"},
    {"id": 6, "name": "Tote Bag 1", "desc": "Simplicity ", "price": 8.90, "image": "tote1.jpg"},
    {"id": 7, "name": "Tote Bag 2", "desc": "Green and natural", "price": 9.00, "image": "tote2.jpeg"},
    {"id": 8, "name": "Tote Bag 3", "desc": "Artsy", "price": 9.5, "image": "tote3.jpg"},
]

cart = [

]


@app.route('/shop')
def shop():
    return render_template('shop.html', products=products)


@app.route('/cart')
def cart_page():
    return render_template('cart.html', cart=cart)


@app.route('/')
def home():
    return render_template('home.html')



@app.route('/add-to-cart', methods=['POST'])
def add_to_cart():
    data = request.get_json()
    product_id = data.get('productId')
    quantity = data.get('quantity', 1)  # Default quantity is 1

    product = next((item for item in products if item['id'] == product_id), None)

    if product:
        # Check if the product is already in the cart
        for item in cart:
            if item['product']['id'] == product_id:
                item['quantity'] += quantity
                return jsonify({"message": "Product quantity updated in the cart"})

        # If the product is not in the cart, add it with the specified quantity
        username = session.get('username', '')
        cart.append({'product': product, 'quantity': quantity, 'username': username})
        return jsonify({"message": "Product added to cart successfully"})
    else:
        return jsonify({"error": "Product not found"}), 404


@app.route('/get-cart')
def get_cart():
    return jsonify(cart)


@app.route('/edit-cart', methods=['POST'])
def edit_cart():
    data = request.get_json()
    product_id = data.get('productId')
    quantity = data.get('quantity')

    # Find the product in the cart
    for item in cart:
        if item['product']['id'] == product_id:
            item['quantity'] = quantity
            return jsonify({"message": "Cart item updated successfully"})

    return jsonify({"error": "Product not found in the cart"}), 404

@app.route('/login', methods=['POST'])
def login():
    user_name = request.form['username']
    users_dict = {}
    db = shelve.open('user.db', 'r')
    try:
        users_dict = db['Users']
    except:
        print("Error in retrieving Users from user.db.")
    users_dict = db['Users']
    db.close()

    if user_name in users_dict:
        user = users_dict.get(user_name)
        session['user_name'] = user_name
        return render_template('base2.html')
    errormessage = "Account not found"
    return render_template('login.html', errormessage=errormessage)

@app.route('/login2', methods=['POST'])
def login2():
    username = request.form.get('username')
    if username == 'john':
        return render_template('login2.html', username=username)
    else:
        errormessage = "Unknown username"
        return render_template('login3.html', errormessage=errormessage)

@app.route('/answerQuestion', methods=['GET', 'POST'])
def answer_question():
    create_quiz = CreateQuiz(request.form)
    if request.method == 'POST':
        questions_dict = {}
        db = shelve.open('question.db', 'c')
        try:
            questions_dict = db['Questions']
        except:
            print("Error in retrieving Answer from questions.db.")
        question = Question.Question(create_quiz.answer.data)
        questions_dict[question.get_question_id()] = question
        db['Questions'] = questions_dict

        db.close()

        return render_template('questionConfirm.html')
    return render_template('answerQuestion.html', form=create_quiz)

@app.route('/retrieveAnswer')
def retrieve_answers():
    questions_dict = {}
    db = shelve.open('question.db', 'r')
    questions_dict = db['Questions']
    db.close()

    questions_list = []
    for key in questions_dict:
        question = questions_dict.get(key)
        questions_list.append(question)
    return render_template('retrieveAnswer.html', count=len(questions_list), questions_list=questions_list)

@app.route('/updateAnswer/<int:id>/', methods=['GET', 'POST'])
def update_answer(id):
    update_quiz = CreateQuiz(request.form)
    if request.method == 'POST' and update_quiz.validate():
        questions_dict ={}
        db = shelve.open('question.db', 'w')
        questions_dict = db['Questions']
        question = questions_dict.get(id)
        question.set_answer(update_quiz.answer.data)

        db['Questions'] = questions_dict
        db.close()
        return redirect(url_for('retrieve_answers'))
    else:
        questions_dict = {}
        db = shelve.open('question.db', 'r')
        questions_dict = db['Questions']
        db.close()
        question = questions_dict.get(id)
        update_quiz.answer.data = question.get_answer()
        return render_template('updateAnswer.html', form=update_quiz)

@app.route('/deleteAnswer/<int:id>', methods=['POST'])
def delete_answer(id):
    questions_dict = {}
    db = shelve.open('question.db', 'w')
    questions_dict = db['Questions']

    questions_dict.pop(id)

    db['Questions'] = questions_dict
    db.close()

    return redirect(url_for('retrieve_answers'))


def get_weather(city_name):
    API_key = '3216660e62d78f49f10c7742e9fdd91b'
    url = f'https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={API_key}&units=metric'

    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        weather_info = {
            'description': data['weather'][0]['description'],
            'temperature': data['main']['temp'],
            'feels_like': data['main']['feels_like'],
            'humidity': data['main']['humidity']
        }
        return weather_info
    else:
        return None



@app.route('/weather', methods=['GET', 'POST'])
def weather():
    if request.method == 'POST':
        city_name = request.form['city_name']
        weather_info = get_weather(city_name)
        if weather_info:
            return render_template('weather.html', weather_info=weather_info, city_name=city_name)
        else:
            return render_template('weather.html', error_message="Unable to fetch weather data.", city_name=city_name)
    else:
        # Default city_name for initial page load
        default_city_name = "Singapore"
        weather_info = get_weather(default_city_name)
        if weather_info:
            return render_template('weather.html', weather_info=weather_info, city_name=default_city_name)
        else:
            return render_template('weather.html', error_message="Unable to fetch weather data.",
                                   city_name=default_city_name)
@app.route('/createFB', methods=['GET', 'POST'])
def create_feedback():
    create_feedback_form = CreateFeedback(request.form)
    if request.method == 'POST':
        feedback_dict = {}
        db = shelve.open('feedback.db','c')

        try:
            feedback_dict = db['Feedbacks']
        except:
            print("Error in retrieving Users from user .db.")

        feedback = Feedback.Feedback(create_feedback_form.first_name.data, create_feedback_form.last_name.data,
                         create_feedback_form.remarks.data)
        feedback_dict[feedback.get_feedback_id()] = feedback
        db['Feedbacks'] = feedback_dict

        db.close()

        return render_template('feedbackConfirm.html')
    return render_template('createFB.html', form=create_feedback_form)

@app.route("/view")
def view():
    return render_template("view.html")

@app.route('/retrieveFB')
def retrieve_feedback():
    feedback_dict = {}
    db = shelve.open('feedback.db', 'r')
    feedback_dict = db['Feedbacks']
    db.close()
    feedback_list = []
    for key in feedback_dict:
        feedback = feedback_dict.get(key)
        feedback_list.append(feedback)
    return render_template('retrieveFB.html', count=len(feedback_list), feedback_list=feedback_list)

@app.route('/updateFB/<int:id>/', methods=['GET', 'POST'])
def update_feedback(id):
    update_feedback_form = CreateFeedback(request.form)
    if request.method == 'POST' and update_feedback_form.validate():
        feedback_dict = {}
        db = shelve.open('feedback.db', 'w')
        feedback_dict = db['Feedbacks']
        feedback = feedback_dict.get(id)
        feedback.set_first_name(update_feedback_form.first_name.data)
        feedback.set_last_name(update_feedback_form.last_name.data)
        feedback.set_remarks(update_feedback_form.remarks.data)
        db['Feedbacks'] = feedback_dict
        db.close()

        return redirect(url_for('retrieve_feedback'))
    else:
        feedback_dict = {}
        db = shelve.open('feedback.db', 'r')
        feedback_dict = db['Feedbacks']
        db.close()
        feedback = feedback_dict.get(id)
        update_feedback_form.first_name.data = feedback.get_first_name()
        update_feedback_form.last_name.data = feedback.get_last_name()
        update_feedback_form.remarks.data = feedback.get_remarks()
        return render_template('updateFB.html', form=update_feedback_form)

@app.route('/deleteFB/<int:id>', methods=['POST'])
def delete_feedback(id):
    feedback_dict = {}
    db = shelve.open('feedback.db')
    feedback_dict = db['Feedbacks']
    feedback_dict.pop(id)
    db['Feedbacks'] = feedback_dict
    db.close()
    return redirect(url_for('retrieve_feedback'))



import requests

def get_climate_news(api_key, query, language='en', page_size=5):
    base_url = 'https://newsapi.org/v2/everything'
    params = {
        'apiKey': api_key,
        'q': query,
        'language': language,
        'pageSize': page_size
    }

    response = requests.get(base_url, params=params)

    if response.status_code == 200:
        news_data = response.json()
        articles = news_data['articles']

        for idx, article in enumerate(articles, start=1):
            print(f"Article {idx}:")
            print(f"Title: {article['title']}")
            print(f"Author: {article['author']}")
            print(f"Description: {article['description']}")
            print(f"URL: {article['url']}")
            print("----")
    else:
        print(f"Error: {response.status_code}")

if __name__ == "__main__":
    # Replace 'YOUR_API_KEY' with your actual News API key
    api_key = '66bbc405da354497809eddc5cfd47531'
    query = 'climate change'  # You can customize the query based on your interests

    get_climate_news(api_key, query)

if __name__ == '__main__':
    app.run(debug=True, port=8000)
