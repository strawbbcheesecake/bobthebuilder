class Question:
    count_id = 0

    def __init__(self, answer):
        Question.count_id += 1
        self.__question_id = Question.count_id
        self.__answer = answer

    def get_question_id(self):
        return self.__question_id

    def get_answer(self):
        return self.__answer


    def set_question_id(self, question_id):
        self.__question_id = question_id

    def set_answer(self, answer):
        self.__answer = answer

