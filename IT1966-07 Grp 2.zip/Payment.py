class Payment:
    count_id = 0

    def __init__(self, full_name, email, address, postal_code, name_on_card, card_number, exp_month, exp_year, cvc):
        Payment.count_id += 1
        self.__payment_id = Payment.count_id
        self.__full_name = full_name
        self.__email = email
        self.__address = address
        self.__postal_code = postal_code
        self.__name_on_card = name_on_card
        self.__card_number = card_number
        self.__exp_month = exp_month
        self.__exp_year = exp_year
        self.__cvc = cvc

    def get_payment_id(self):
        return self.__payment_id

    def get_full_name(self):
        return self.__full_name

    def get_email(self):
        return self.__email

    def get_address(self):
        return self.__address

    def get_postal_code(self):
        return self.__postal_code

    def get_name_on_card(self):
        return self.__name_on_card

    def get_card_number(self):
        return self.__card_number

    def get_exp_month(self):
        return self.__exp_month

    def get_exp_year(self):
        return self.__exp_year

    def get_cvc(self):
        return self.__cvc

    def set_payment_id(self, payment_id):
        self.__payment_id = payment_id

    def set_full_name(self, full_name):
        self.__full_name = full_name

    def set_email(self, email):
        self.__email = email

    def set_address(self, address):
        self.__address = address

    def set_postal_code(self, postal_code):
        self.__postal_code = postal_code

    def set_name_on_card(self, name_on_card):
        self.__name_on_card = name_on_card

    def set_card_number(self, card_number):
        self.__card_number = card_number

    def set_exp_month(self, exp_month):
        self.__exp_month = exp_month
    def set_exp_year(self, exp_year):
        self.__exp_year = exp_year

    def set_cvc(self, cvc):
        self.__cvc = cvc
