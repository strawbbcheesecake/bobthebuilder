from wtforms import Form, StringField, SelectField, validators, SearchField


class CreatePaymentForm(Form):
    full_name = StringField('Full Name', [validators.Length(min=1, max=150), validators.DataRequired()])
    email = StringField('Email', [validators.Length(min=1, max=150), validators.DataRequired()])
    address = StringField('Address', [validators.Length(min=1, max=150), validators.DataRequired()])
    postal_code = StringField('Postal Code', [validators.Length(min=6, max=6), validators.DataRequired(), validators.Regexp('^\d+$',
                                            message='Postal Code must only contain numeric digits.')])
    name_on_card = StringField('Name on Card', [validators.Length(min=1, max=150), validators.DataRequired()])
    card_number = StringField('Card Number', [validators.Length(min=16, max=16), validators.DataRequired(), validators.Regexp('^\d+$',
                                            message='Card Number must only contain numeric digits.')])
    exp_month = SelectField('Expiration Month', [validators.DataRequired()],
                         choices=[('', 'Select'), ('01', 'January'), ('02', 'February'), ('03', 'March'), ('04', 'April'),
                                  ('05', 'May'), ('06', 'June'), ('07', 'July'), ('08', 'August'), ('09', 'September'),
                                  ('10', 'October'), ('11', 'November'), ('12', 'December')],
                         default='')
    exp_year = SelectField('Expiration Year', [validators.DataRequired()],
                           choices=[('', 'Select'), ('2024', '2024'), ('2025', '2025'), ('2026', '2026'),
                                    ('2027', '2027'), ('2028', '2028'), ('2029', '2029'), ('2030', '2030')],
                           default='')
    cvc = StringField('CVC', [validators.Length(min=3, max=3), validators.DataRequired(), validators.Regexp('^\d+$',
                                            message='CVC must only contain numeric digits.')])

