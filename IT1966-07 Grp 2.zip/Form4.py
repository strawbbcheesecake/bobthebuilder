from wtforms import Form, StringField, TextAreaField, validators

class CreateFeedback(Form):
    first_name = StringField('First Name:', [validators.Length(min=1, max=150), validators.DataRequired()], render_kw={"placeholder": "e.g John"})
    last_name = StringField('Last Name:', [validators.Length(min=1, max=150), validators.DataRequired()], render_kw={"placeholder": "e.g Doe"})
    remarks = TextAreaField('Remarks', [validators.Length(min=1, max=500), validators.DataRequired()], render_kw={"placeholder": "Type here..."})