from wtforms import Form, StringField, RadioField, SelectField, validators
from wtforms import EmailField

class NumberOnly(object):
    def __call__(self, form, field):
        if not field.data.isdigit():
            raise validators.ValidationError('Phone number must contain only digits')

class CreateUserForm(Form):
    first_name = StringField('First Name', [validators.Length(min=1, max=150), validators.DataRequired()])
    last_name = StringField('Last Name', [validators.Length(min=1, max=150), validators.DataRequired()])
    email = EmailField('Email', [validators.email(),validators.DataRequired()])
    gender = SelectField('Gender', [validators.DataRequired()], choices=[('', 'Select'), ('F', 'Female'), ('M', 'Male')], default='')
    user_name = StringField('User Name', [validators.Length(min=1, max=150), validators.DataRequired()])
    password = StringField('Password', [validators.Length(min=1, max=150), validators.DataRequired()])
    phone_number = StringField('Phone Number',validators=[validators.InputRequired(), NumberOnly(), validators.Length(min=8)])