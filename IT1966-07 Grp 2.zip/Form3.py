from wtforms import Form, TextAreaField, validators


class CreateQuiz(Form):
    answer = TextAreaField('What are some potential strategies for individuals to reduce their carbon footprint and '
                            'mitigate climate change?', [validators.DataRequired()])